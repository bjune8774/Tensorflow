import os
import glob
import tensorflow as tf
import numpy as np
import json
import sys

sys.path.append('libs')
sys.path.append('coco_annotations')

from PIL import Image
from pascal_voc_io import PascalVocWriter
from utils import is_grey_scale, return_to_label_list
from mscoco_label_map import category_map

flags = tf.app.flags
INPUT_IMAGES_DIR = '/work/nas/images/ObjectDetection/cocodataset/dataset/classes_80_refine/val2017'
INPUT_BOX_ANNOTATIONS='./coco_annotations/instances_val2017.json'

def writeVOCFormat(imageList, coco_annotations_index):
    for imagePath in imageList:
        image = imagePath.split('/')[-1][:-4]
        anns = coco_annotations_index[int(image)]

        imagePath = imagePath
        xmlPath = imagePath[:-4] + '.xml'

        if os.path.isfile(xmlPath):
            os.remove(xmlPath)

        imgFolderPath = os.path.dirname(imagePath)
        imgFolderName = os.path.split(imgFolderPath)[-1]
        imgFileName = os.path.basename(imagePath)

        with Image.open(imagePath) as imageTemp:
            width, height = imageTemp.size
            imageShape = [height, width, 1 if is_grey_scale(imagePath) else 3]

        writer = PascalVocWriter(imgFolderName, imgFileName, imageShape, localImgPath=imagePath)
        writer.verified = False

        for annotation in anns:
            label = category_map[annotation['category_id']]
            x, y, width, height = annotation['bbox']
            xmin = int(x)
            ymin = int(y)
            xmax = int(x + width)
            ymax = int(y + height)

            if label in return_to_label_list('labelmap/labelmap.txt'):
                writer.addBndBox(xmin, ymin, xmax, ymax, label, 0)

        writer.save(targetFile=xmlPath)
        print('save to' + xmlPath)

def main(_):
    with tf.gfile.GFile(INPUT_BOX_ANNOTATIONS, 'r') as fid:
        groundtruth_data = json.load(fid)
        images = groundtruth_data['images']

        coco_annotations_index = {}
        if 'annotations' in groundtruth_data:
            tf.logging.info('Found groundtruth annotations. Building annotations index.')

            for annotation in groundtruth_data['annotations']:
                image_id = annotation['image_id']

                if image_id not in coco_annotations_index:
                    coco_annotations_index[image_id] = []
                coco_annotations_index[image_id].append(annotation)

        for image in images:
            image_id = image['id']
            if image_id not in coco_annotations_index:
                coco_annotations_index[image_id] = []

    DIRS = glob.glob(INPUT_IMAGES_DIR + '/*')
    for dir in DIRS:
        imageList = glob.glob(dir + '/*.jpg')
        writeVOCFormat(imageList, coco_annotations_index)

if __name__=='__main__':
    tf.app.run()
