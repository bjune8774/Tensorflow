from __future__ import division
from __future__ import print_function
from __future__ import absolute_import

import os
import io
import pandas as pd
import tensorflow as tf
import numpy  as np
import threading
import contextlib2

from PIL import Image
from object_detection.utils import dataset_util
from collections import namedtuple, OrderedDict
from six.moves import xrange
from datetime import datetime

from object_detection.dataset_tools import tf_record_creation_util

flags = tf.app.flags
flags.DEFINE_string('csv_input', './combination_valid.csv', 'Path to the CSV input')
tf.flags.DEFINE_string('output_tf_record_path_prefix', './20190211_combo_valid.tfrecord', 'Path to the output TFRecord. The shard index and the number of shards will be appended for each output shard.')
tf.flags.DEFINE_integer('num_shards', 8, 'Number of TFRecord shards')
tf.flags.DEFINE_integer('num_threads', 8, 'Number of threads to preprocess the images.')
FLAGS = flags.FLAGS

def split(df, group):
    data = namedtuple('data', ['filename', 'object'])
    gb = df.groupby(group)
    return [data(filename, gb.get_group(x)) for filename, x in zip(gb.groups.keys(), gb.groups)]

def class_text_to_int(row_label):
    return {
        'sandwich_chesse' : 1,
        'sandwich_ham' : 2,
        'sandwich_ham_cheese' : 3,
        'drink_milk' : 4,
        'drink_apple' : 5,
        'drink_orange' : 6,
        'macaron_choco' : 7,
        'macaron_mint' : 8,
        'macaron_strawberry' : 9
    }.get(row_label, 0)

    # case1
    # return {
    #     'drink_apple': 1,
    #     'sandwich_ham': 2,
    #     'macaron_strawberry': 3
    # }.get(row_label, 0)

    # case2
    # return {
    #     'drink_milk': 1,
    #     'sandwich_ham_cheese': 2,
    #     'macaron_choco': 3
    # }.get(row_label, 0)

    # case3
    # return {
    #     'drink_orange': 1,
    #     'sandwich_chesse': 2,
    #     'macaron_mint': 3
    # }.get(row_label, 0)

def resize_image_threshold(threshold, image_io, xmin, ymin, xmax, ymax):
    with Image.open(image_io) as image:
        resized_image = image
        width, height = image.size

        while ((width > threshold) | (height > threshold)):
            height = int(height / 2)
            width = int(width / 2)
            resized_image = image.resize((width, height))

            xmin = xmin / 2
            xmax = xmax / 2
            ymin = ymin / 2
            ymax = ymax / 2

        image_bytes = io.BytesIO()
        resized_image.save(image_bytes, format='JPEG')
        resized_image = image_bytes.getvalue()

    return resized_image, width, height, xmin, xmax, ymin, ymax

def create_tf_example(thread_index, ranges, groupTable, output_tfrecords):
    num_threads = FLAGS.num_threads
    num_shards = FLAGS.num_shards

    assert not num_shards % num_threads
    num_shards_per_batch = int(num_shards / num_threads)
    shard_ranges = np.linspace(ranges[thread_index][0], ranges[thread_index][1], num_shards_per_batch + 1).astype(int)

    for s in xrange(num_shards_per_batch):
        files_in_shard = np.arange(shard_ranges[s], shard_ranges[s + 1], dtype=int)

        for i in files_in_shard:
            group = groupTable[i]
            image_id = group.filename.split('/')[-1][:-4]
            image_id_to_ascii = ''.join(str(ord(c)) for c in image_id)

            width, height = 0, 0
            xmins = []
            xmaxs = []
            ymins = []
            ymaxs = []
            classes_text = []
            classes = []

            for index, row in group.object.iterrows():
                with tf.gfile.GFile(os.path.join(row['path'], '{}'.format(group.filename)), 'rb') as fid:
                    encoded_jpg = fid.read()

                filename = group.filename.encode('utf8')
                image_format = b'jpg'
                encoded_jpg_io = io.BytesIO(encoded_jpg)


                temp = class_text_to_int(row['class'])
                if temp != 0:
                    resized_image, width, height,  xmin, xmax, ymin, ymax = resize_image_threshold(1200, encoded_jpg_io, row['xmin'], row['ymin'], row['xmax'], row['ymax'])
                    xmins.append( float("{0:.2f}".format(xmin / width)))
                    xmaxs.append(float("{0:.2f}".format(xmax / width)))
                    ymins.append(float("{0:.2f}".format(ymin / height)))
                    ymaxs.append(float("{0:.2f}".format(ymax / height)))
                    classes_text.append(row['class'].encode('utf8'))
                    classes.append(class_text_to_int(row['class']))

            if height != 0:
                tf_example = tf.train.Example(features=tf.train.Features(feature={
                    'image/height': dataset_util.int64_feature(height),
                    'image/width': dataset_util.int64_feature(width),
                    'image/filename': dataset_util.bytes_feature(filename),
                    'image/encoded': dataset_util.bytes_feature(resized_image),
                    'image/format': dataset_util.bytes_feature(image_format),
                    'image/object/bbox/xmin': dataset_util.float_list_feature(xmins),
                    'image/object/bbox/xmax': dataset_util.float_list_feature(xmaxs),
                    'image/object/bbox/ymin': dataset_util.float_list_feature(ymins),
                    'image/object/bbox/ymax': dataset_util.float_list_feature(ymaxs),
                    'image/object/class/text': dataset_util.bytes_list_feature(classes_text),
                    'image/object/class/label': dataset_util.int64_list_feature(classes),
                }))

                if tf_example:
                    shard_idx = int(image_id_to_ascii, 16) % FLAGS.num_shards
                    output_tfrecords[shard_idx].write(tf_example.SerializeToString())

                print(height, width, filename, image_format, xmins, xmaxs, ymins, ymaxs, classes_text, classes)

def main(_):
    tf.logging.set_verbosity(tf.logging.INFO)
    required_flags = ['csv_input']

    for flag_name in required_flags:
        if not getattr(FLAGS, flag_name):
            raise ValueError('Flag --{} is required'.format(flag_name))

    annotations = pd.read_csv(FLAGS.csv_input)
    groupTable = split(annotations, 'filename')
    tf.logging.log(tf.logging.INFO, 'Found %d images...', len(groupTable))

    with contextlib2.ExitStack() as tf_record_close_stack :
        output_tfrecords = tf_record_creation_util.open_sharded_output_tfrecords(tf_record_close_stack, FLAGS.output_tf_record_path_prefix,FLAGS.num_shards)
        spacing = np.linspace(0, len(groupTable), FLAGS.num_threads + 1).astype(np.int)
        ranges = []
        threads = []

        for i in xrange(len(spacing) - 1):
            ranges.append([spacing[i], spacing[i + 1]])
        tf.logging.log(tf.logging.INFO,'Launching %d threads for spacings : %s' % (FLAGS.num_threads, ranges))
        coord = tf.train.Coordinator()

        for thread_index in xrange(len(ranges)):
            args = (thread_index, ranges, groupTable, output_tfrecords)
            t = threading.Thread(target=create_tf_example, args=args)

            t.start()
            threads.append(t)

        coord.join(threads)
        tf.logging.log(tf.logging.INFO,'%s: Finished writing all %d images in data set.' % (datetime.now(), len(groupTable)))

if __name__ == '__main__':
    tf.app.run()