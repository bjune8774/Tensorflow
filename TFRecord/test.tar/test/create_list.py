import os
import glob
import xml.etree.ElementTree as ET

# COCO : 76 classes
# OID : 53 classes
TRAIN_DIR1 = '/work/nas/images/ObjectDetection/oid_dataset_refine/datasets'
TRAIN_DIR2 = '/work/nas/images/ObjectDetection/cocodataset/dataset/classes_80_refine/train2017'
VAL_DIR1 = '/work/nas/images/ObjectDetection/oid_dataset_refine/datasets_valid'
VAL_DIR2 = '/work/nas/images/ObjectDetection/cocodataset/dataset/classes_80_refine/val2017'

def img_to_txt(file):
    f = open(file, 'w')

    if file == 'trainval.txt':
        img_dirs = glob.glob(os.path.join(TRAIN_DIR1 + '/*'))
        img_dirs.extend(glob.glob(os.path.join(TRAIN_DIR2 + '/*')))
        
        img_list = []
        for idx, dir in enumerate(img_dirs) :
            print("{} Dir name : {}".format(idx + 1, dir ))
            img_list.extend(glob.glob(os.path.join(dir + '/*.jpg')))

    elif file == 'test.txt':
        img_dirs = glob.glob(os.path.join(VAL_DIR1 + '/*'))
        img_dirs.extend(glob.glob(os.path.join(VAL_DIR2 + '/*')))

        img_list = []
        for idx, dir in enumerate(img_dirs) :
            print("{} Dir name : {}".format(idx + 1, dir ))
            img_list.extend(glob.glob(os.path.join(dir + '/*.jpg')))

        f1 = open('test_name_size.txt', 'w')
        for idx, img in enumerate(img_list) :
            xmlfile = img[:-4]+'.xml'
            if os.path.isfile(xmlfile):
                tree = ET.parse(xmlfile)
                root = tree.getroot()
                content = img[:-4] + ' ' + root.find('size')[0].text + ' ' + root.find('size')[1].text + '\n'
                f1.write(content)
                
                print("{} content : ".format(idx + 1) + content + "in " + f1.name)

        f1.close()

    length = len(img_list)

    for idx, img in enumerate(img_list) :
        contentToWrite = img + ' ' + img[:-4] + '.xml\n'
        print('({}%, {}/{}) Write '.format((idx + 1) * 100 / length, idx + 1, length) + contentToWrite +' in ' + f.name)
        f.write(contentToWrite)

    f.close()

def main():
    for dataset in ['trainval', 'test']:
        file = dataset + '.txt'
        if os.path.isfile(file):
            os.remove(file)
        
        f = open(file, 'w')
        f.close()

        img_to_txt(file)

if __name__ == '__main__':
    main()
