cur_dir=$(cd $( dirname ${BASH_SOURCE[0]} ) && pwd )
root_dir=/home/dg.jung/caffe

redo=1
data_root_dir=""
dataset_name="LGEOD1.0_448"
mapfile="lgeod1.prototxt"
anno_type="detection"
db="lmdb"
min_dim=0
max_dim=0
width=448
height=448

extra_cmd="--encode-type=jpg --encoded"
if [ $redo ]
then
  extra_cmd="$extra_cmd --redo"
fi
for subset in test trainval
do
  python $root_dir/scripts/create_annoset.py --anno-type=$anno_type --label-map-file=$mapfile --min-dim=$min_dim --max-dim=$max_dim --resize-width=$width --resize-height=$height --check-label $extra_cmd / $subset.txt /work/nas/images/ObjectDetection/$dataset_name/$db/$dataset_name"_"$subset"_"$db $root_dir/examples/$dataset_name
done
