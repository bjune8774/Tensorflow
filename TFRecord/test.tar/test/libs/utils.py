from PIL import Image

def is_grey_scale(img_path):
    im = Image.open(img_path).convert('RGB')
    w,h = im.size
    for i in range(w):
        for j in range(h):
            r,g,b = im.getpixel((i,j))
            if r != g != b: return False
    return True

def return_to_label_list(txt):
    f = open(txt, 'r')

    label_list = []

    while(1):
        line = f.readline()
        try:escape = line.index('\n')
        except:escape = len(line)
        if line:label_list.append(line[0:escape])
        else:break
    f.close()

    return label_list