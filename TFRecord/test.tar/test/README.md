Refer http://collab.lge.com/main/display/MILTWOTEAM/2.+labelImg_generate_tfrecord

Tensorflow 용 tfRecord file 생성 
Caffe 용 lmdb file 생성