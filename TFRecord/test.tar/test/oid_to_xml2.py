import os
import glob
import tensorflow as tf
import pandas as pd
import numpy as np
import ast
import sys

sys.path.append('libs')

from PIL import Image
from libs.pascal_voc_io import PascalVocWriter
from libs.utils import is_grey_scale, return_to_label_list

flags = tf.app.flags
# INPUT_IMAGES_DIR = '/work/nas/images/ObjectDetection/oid_dataset_refine/datasets'
INPUT_IMAGES_DIR = '/work/nas/images/ObjectDetection/google_oid/classes_600/oid_af_v2_valid'
INPUT_BOX_ANNOTATIONS = './oid_annotations/validation-annotations-bbox.csv'
LABEL_ANNOTATIONS = './oid_annotations/label_dict.txt'

def loadAnnotations(INPUT_IMAGES_DIR, INPUT_BOX_ANNOTATIONS):
    INPUT_IMAGES_DIR = INPUT_IMAGES_DIR
    images = glob.glob(INPUT_IMAGES_DIR + '/*.jpg')
    bboxsAnnsCSV = pd.read_csv(INPUT_BOX_ANNOTATIONS, encoding='utf-8')
    image_ids = [os.path.splitext(os.path.basename(v))[0] for v in images]
    df_image_ids = pd.DataFrame({'ImageID': image_ids})
    bbox_annotations = pd.merge(bboxsAnnsCSV, df_image_ids)
    return bbox_annotations

def _prepared(INPUT_IMAGES_DIR, INPUT_BOX_ANNOTATIONS, LABEL_ANNOTATIONS):
    bbox_annotations = loadAnnotations(INPUT_IMAGES_DIR, INPUT_BOX_ANNOTATIONS)
    with open(LABEL_ANNOTATIONS, 'r') as f:
        for line in f:
            label_dict = ast.literal_eval(line)
    return bbox_annotations, np.unique(bbox_annotations['ImageID'].values.tolist()), label_dict

def findLabelText(label_dict, labelCode):
    return [name for name, code in label_dict.items() if code == labelCode][0]

def main(_):
    DIRS = glob.glob(INPUT_IMAGES_DIR + '/*')
    print(DIRS)
    for dir in DIRS:
        bbox_annotations, image_ids, label_dict = _prepared(dir, INPUT_BOX_ANNOTATIONS, LABEL_ANNOTATIONS)

        for image in image_ids:
            select_index = np.where(bbox_annotations['ImageID'] == image)
            imageAnns = bbox_annotations.iloc[select_index]

            imagePath = dir+'/'+image+'.jpg'
            xmlPath = dir+'/'+image+'.xml'

            # imagePath = INPUT_IMAGES_DIR + '/' + image + '.jpg'
            # xmlPath = INPUT_IMAGES_DIR +'/'+image+'.xml'

            if os.path.isfile(xmlPath):
                os.remove(xmlPath)

            imgFolderPath = os.path.dirname(imagePath)
            imgFolderName = os.path.split(imgFolderPath)[-1]
            imgFileName = os.path.basename(imagePath)

            with Image.open(imagePath) as imageTemp:
                width, height = imageTemp.size
                imageShape = [height, width, 1 if is_grey_scale(imagePath) else 3]

            writer = PascalVocWriter(imgFolderName, imgFileName, imageShape, localImgPath=imagePath)
            writer.verified = False

            for index, row in imageAnns.iterrows():
                label = findLabelText(label_dict, row['LabelName'])

                if label in return_to_label_list('labelmap/af_labelmap.txt'):
                    writer.addBndBox(int(row['XMin'] * width), int(row['YMin'] * height), int(row['XMax'] * width), int(row['YMax'] * height), label, 0)

            writer.save(targetFile=xmlPath)
            print('save to ' + xmlPath)

if __name__ == '__main__':
    tf.app.run()
